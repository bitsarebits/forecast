import { useEffect } from 'react';
import './ForecastPage.css'
import axios from 'axios';

function ForecastPage(){

    // Methods
    //  dichiaro la funzione async (asincrona)
    const fetchData = async () => {
        // res è una promise => await aspetta la risposta (promessa risolta)
        const res = await axios.get(
            "https://api.open-meteo.com/v1/forecast?latitude=52.52&longitude=13.41&current=temperature_2m,wind_speed_10m&hourly=temperature_2m,relative_humidity_2m,wind_speed_10m"
        ).then( res =>{     // then ==> promessa risolta
            console.log(res.data);
        }).catch(() => {
            console.error("Error while loading data");
        });

        console.log("ciao");
    }

    // Effects
    useEffect(() =>{        // funzione eseguita ogni volta che cambia lo stato + tra le []
        // mettiamo qui le chiamate API, anche se in realtà si usano altre librerie
        fetchData();
    }, [])

    // Render
    return(
        <div className='forecast-container'>
            <h3>
                Forecast
            </h3>
        </div>
    );
}

export default ForecastPage;